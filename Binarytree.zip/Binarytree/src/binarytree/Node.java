/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package binarytree;



public class Node {
    Node sol;
    Node sag;
    int veri;

    public Node(int veri) {
        this.veri = veri;
    }
    
    
}
