package binarytree;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.Scanner;
import java.util.Stack;

public class Tree {
    Node root;
    
    public Tree(){
        root=null;
    }
    
        Node yeniNode(int veri){   
        root=new Node(veri);
        System.out.println(veri+" Agaca Eklendi");
        return root;
    }
        Scanner sc = new Scanner(System.in);
        Node Kok(Node root,int veri){ 
            if(root==null){
        System.out.println("Agac Bos Oldugundan Baslangic kokunu giriniz:");
        veri=sc.nextInt();
        root=yeniNode(veri);
 }
            return root;
        }    
        
      Node kokeekle(Node root,int veri,int aranan){
              Node gecici;
            if(root!=null){
            if(root.sol!=null){
            if(root.sol.veri==aranan){
               gecici=root.sol;
               root.sol=yeniNode(veri);
               root.sol.sol=gecici;
            }
            else {
                root.sag=kokeekle(root.sag, veri, aranan);
                root.sol=kokeekle(root.sol, veri, aranan);
                
            }
            }
            if(root.sag!=null){
            if(root.sag.veri==aranan){
               gecici=root.sag;
               root.sag=yeniNode(veri);
               root.sag.sag=gecici;
            }
            else {
              root.sol=kokeekle(root.sol, veri, aranan);
              root.sag=kokeekle(root.sag, veri, aranan); 
            }
            }  
            }
      
        return root;    
    }
      Node SolaEkle(Node root,int veri,int veri2){
        if(root!=null){
            if(root.veri==veri){
                if(root.sol==null)
                root.sol=yeniNode(veri2);
                else
                    System.out.println("Kokun solu dolu oldugundan eklenemez.");
            }
            else{
               root.sol=SolaEkle(root.sol,veri,veri2);
               root.sag=SolaEkle(root.sag,veri,veri2);
        }      
        }
        return root;
       } 
       Node SagaEkle(Node root,int veri,int veri2){
        if(root!=null){
            if(root.veri==veri){
                if(root.sag==null)
                root.sag=yeniNode(veri2);
               else
                    System.out.println("Kokun sagi dolu oldugundan eklenemez.");
            }
            else{  
               root.sag=SagaEkle(root.sag,veri,veri2);
               root.sol=SagaEkle(root.sol,veri,veri2);
            }
        }
        return root;
       }
       Node Sil(Node root,int veri){
         if(root==null){
             return root;
         } 
         else if(root.veri==veri){
           root.sol=null;
           root.sag=null;
           root.sag=Sil(root.sag,veri);
           root.sol=Sil(root.sol, veri);
           root=null;
         }
         else{
           root.sag=Sil(root.sag,veri);
           root.sol=Sil(root.sol, veri);
         }
           return root;
    }
    public void yazdir(Node node) {
    Stack<Node> s1 = new Stack<Node>();
    Stack<Node> s2 = new Stack<Node>();

    s1.push(node);
    while (!s1.isEmpty() || !s2.isEmpty()) {

      while (!s1.isEmpty()) {
        Node tmp = s1.pop();
        System.out.print(tmp.veri + " ");

        if (tmp.sol != null) {
          s2.push(tmp.sol);
        }

        if (tmp.sag != null) {
          s2.push(tmp.sag);
        }
      }
      System.out.println();

      while (!s2.isEmpty()) {
        Node tmp = s2.pop();
        System.out.print(tmp.veri + " ");

        if (tmp.sag != null) {
          s1.push(tmp.sag);
        }

        if (tmp.sol != null) {
          s1.push(tmp.sol);
        }
      }
      System.out.println();
    }
  }
   
}
