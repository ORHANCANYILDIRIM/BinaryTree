/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package binarytree;

                                       /* Orhancan Yıldırım */
                                       /*    02210224036    */
import java.util.Scanner;


public class BinaryTree {

    
    public static void main(String[] args) {
      
        Scanner sc = new Scanner(System.in);
        Tree tree = new Tree();
        int secim=-1;
        int veri=0;
        int aranan;
        while(secim!=0){
            System.out.println("\n1-Kok ekle");
            System.out.println("2-Saga ekle");
            System.out.println("3-Solaa ekle");
            System.out.println("4-Silme islemi");
            System.out.println("5-Yazdir");
            System.out.println("0-Cikis");
            tree.Kok(tree.root,veri);
            System.out.print("Seciminizi giriniz :");
            secim=sc.nextInt();
            
            switch(secim){
                case 1:
                    System.out.println("Eklenecek degeri giriniz:");
                    veri=sc.nextInt();
                    System.out.println("Hangi kokten once eklenecegini giriniz:");
                    aranan=sc.nextInt();
                    tree.root=tree.kokeekle(tree.root,veri,aranan);
                    break;
                case 2:
                    System.out.println("Hangi kokun sagina eklenecegini giriniz:");
                    veri=sc.nextInt();
                    System.out.println("Eklenecek degeri giriniz:");
                    aranan=sc.nextInt();
                    tree.root=tree.SagaEkle(tree.root,veri,aranan);
                    break;
                case 3:
                    System.out.println("Hangi kokun soluna eklenecegini giriniz:");
                    veri=sc.nextInt();
                    System.out.println("Eklenecek degeri giriniz:");
                    aranan=sc.nextInt();
                    tree.root=tree.SolaEkle(tree.root,veri,aranan);
                    break;
                case 4:
                    System.out.println("Silinecek degeri giriniz:");
                    veri=sc.nextInt();
                    tree.root=tree.Sil(tree.root,veri);
                    break;
                case 5:
                    tree.yazdir(tree.root);
                    
            }
        }
    }
    
}

